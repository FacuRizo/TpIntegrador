package modelo;

public enum ResultadoEnum 
{
	Ganador,
	Empate,
	Perdedor
}
